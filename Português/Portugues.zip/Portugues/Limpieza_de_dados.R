#Neste Script você encontrará uma maneira de limpar dados


# Instalar pacotes --------------------------------------------------------
#install.packages("readxl")
#install.packages("tidyverse")
#install.packages("lubridate")
#install.packages("psych")

# Ativar bibliotecas ------------------------------------------------------
library(readxl)
library(tidyverse)

library(psych)
library(lubridate)


# Importar dados ----------------------------------------------------------
Dados <- read_excel("Dummy_Data.xlsx")

# explorar dados ----------------------------------------------------------

#do R base
dim(Dados)

#do pacote "tidyverse"
#glimpse nos permite ver o número de colunas e linhas dos dados.
#Da mesma forma, nos permite ver o nome das colunas e a classe a que pertencem
glimpse(Dados)

#do pacote "psych"
#Esta função é útil para variáveis quantitativas
describe(Dados)

#do R base
#Esta função nos mostra a classe e o modo das variáveis do banco de dados
summary(Dados)

#do R base
#Esta função nos mostra a “estrutura” geral dos dados.
str(Dados)

#do R base
#Esta função nos mostra a classe de cada variável
#The class() is used to define/identify what "type" an object is from the point of view of object-oriented programming in R.
class(Dados$id)

#typeof() gives the "type" of object from R's point of view
typeof(Dados$id)

#gives the "type" of object from the point of view of Becker, Chambers & Wilks (1988)
mode(Dados$id)

# Limpieza de dados -------------------------------------------------------

is.na()

na.omit()

as.numeric()

as.character()

as.Date()

as.factor()

drop_duplicates()

dmy()

mutate()
